import React, { useState } from 'react';
import { MEDIA_TYPES, saveToLocalStorage, loadFromLocalStorage } from '../utils/storage';

const AddMediaForm = ({ onAdd }) => {
  const [title, setTitle] = useState('');
  const [mediaType, setMediaType] = useState(MEDIA_TYPES.MOVIE);
  const [totalSeasons, setTotalSeasons] = useState('');
  const [totalEpisodes, setTotalEpisodes] = useState('');
  const [totalMinutes, setTotalMinutes] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    
    const newMedia = {
      id: Date.now(),
      title,
      mediaType,
      totalSeasons: mediaType === MEDIA_TYPES.TV_SERIES ? parseInt(totalSeasons) : null,
      totalEpisodes: mediaType === MEDIA_TYPES.TV_SERIES ? parseInt(totalEpisodes) : null,
      totalMinutes: mediaType === MEDIA_TYPES.MOVIE ? parseInt(totalMinutes) : null
    };

    const mediaItems = loadFromLocalStorage('mediaItems') || [];
    mediaItems.push(newMedia);
    saveToLocalStorage('mediaItems', mediaItems);
    
    // CHANGED THIS LINE - removed passing newMedia
    onAdd();  // Now just calls onAdd without parameters
    resetForm();
  };

  // THIS PART STAYS EXACTLY THE SAME
  const resetForm = () => {
    setTitle('');
    setMediaType(MEDIA_TYPES.MOVIE);
    setTotalSeasons('');
    setTotalEpisodes('');
    setTotalMinutes('');
  };

  // THIS PART STAYS EXACTLY THE SAME
  return (
    <div className="add-media-form">
      <h2>Add New Media</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Title:</label>
          <input 
            type="text" 
            value={title} 
            onChange={(e) => setTitle(e.target.value)} 
            required 
          />
        </div>
        
        <div>
          <label>Type:</label>
          <select 
            value={mediaType} 
            onChange={(e) => setMediaType(e.target.value)}
          >
            <option value={MEDIA_TYPES.MOVIE}>Movie</option>
            <option value={MEDIA_TYPES.TV_SERIES}>TV Series</option>
          </select>
        </div>
        
        {mediaType === MEDIA_TYPES.TV_SERIES && (
          <>
            <div>
              <label>Total Seasons:</label>
              <input 
                type="number" 
                value={totalSeasons} 
                onChange={(e) => setTotalSeasons(e.target.value)} 
                min="1"
              />
            </div>
            <div>
              <label>Total Episodes:</label>
              <input 
                type="number" 
                value={totalEpisodes} 
                onChange={(e) => setTotalEpisodes(e.target.value)} 
                min="1"
              />
            </div>
          </>
        )}
        
        {mediaType === MEDIA_TYPES.MOVIE && (
          <div>
            <label>Total Minutes:</label>
            <input 
              type="number" 
              value={totalMinutes} 
              onChange={(e) => setTotalMinutes(e.target.value)} 
              min="1"
            />
          </div>
        )}
        
        <button type="submit">Add Media</button>
      </form>
    </div>
  );
};

export default AddMediaForm;