import React, { useState } from 'react';
import { loadFromLocalStorage, saveToLocalStorage } from '../utils/storage';

const ProgressTracker = ({ media, onClose, onProgressUpdate }) => {
  const [currentSeason, setCurrentSeason] = useState('');
  const [currentEpisode, setCurrentEpisode] = useState('');
  const [minutesWatched, setMinutesWatched] = useState('');
  const [watchedWith, setWatchedWith] = useState('');
  const [notes, setNotes] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    
    const progress = {
      id: Date.now(),
      mediaId: media.id,
      date: new Date().toISOString(),
      currentSeason: media.mediaType === 'TV Series' ? parseInt(currentSeason) : null,
      currentEpisode: media.mediaType === 'TV Series' ? parseInt(currentEpisode) : null,
      minutesWatched: parseInt(minutesWatched) || 0,
      watchedWith,
      notes
    };

    const userProgress = loadFromLocalStorage('userProgress') || [];
    userProgress.push(progress);
    saveToLocalStorage('userProgress', userProgress);
    
    // NEW: Call the refresh callback instead of showing alert
    onProgressUpdate();
    onClose();
  };

  return (
    <div className="progress-tracker-modal">
      <div className="modal-content">
        <h2>Update Progress for {media.title}</h2>
        <button className="close-button" onClick={onClose}>×</button>
        
        <form onSubmit={handleSubmit}>
          {media.mediaType === 'TV Series' && (
            <>
              <div>
                <label>Current Season:</label>
                <input 
                  type="number" 
                  value={currentSeason} 
                  onChange={(e) => setCurrentSeason(e.target.value)} 
                  min="1"
                  max={media.totalSeasons}
                />
              </div>
              <div>
                <label>Current Episode:</label>
                <input 
                  type="number" 
                  value={currentEpisode} 
                  onChange={(e) => setCurrentEpisode(e.target.value)} 
                  min="1"
                  max={media.totalEpisodes}
                />
              </div>
            </>
          )}
          
          <div>
            <label>Minutes Watched:</label>
            <input 
              type="number" 
              value={minutesWatched} 
              onChange={(e) => setMinutesWatched(e.target.value)} 
              min="1"
              max={media.mediaType === 'Movie' ? media.totalMinutes : null}
            />
          </div>
          
          <div>
            <label>Watched With:</label>
            <input 
              type="text" 
              value={watchedWith} 
              onChange={(e) => setWatchedWith(e.target.value)} 
              placeholder="Friends, family, etc."
            />
          </div>
          
          <div>
            <label>Notes:</label>
            <textarea 
              value={notes} 
              onChange={(e) => setNotes(e.target.value)} 
              placeholder="Any additional notes..."
            />
          </div>
          
          <button type="submit">Save Progress</button>
        </form>
      </div>
    </div>
  );
};

export default ProgressTracker;