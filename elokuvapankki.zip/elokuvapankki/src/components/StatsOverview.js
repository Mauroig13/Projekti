import React, { useEffect, useState } from 'react';
import { loadFromLocalStorage, MEDIA_TYPES } from '../utils/storage';

const StatsOverview = ({ refreshFlag }) => {  // Add refreshFlag prop
  const [mediaItems, setMediaItems] = useState([]);
  const [progressItems, setProgressItems] = useState([]);

  // Add useEffect to load data when component mounts or refreshFlag changes
  useEffect(() => {
    setMediaItems(loadFromLocalStorage('mediaItems') || []);
    setProgressItems(loadFromLocalStorage('userProgress') || []);
  }, [refreshFlag]);

  const movies = mediaItems.filter(item => item.mediaType === MEDIA_TYPES.MOVIE);
  const tvSeries = mediaItems.filter(item => item.mediaType === MEDIA_TYPES.TV_SERIES);

  const totalMinutesWatched = progressItems.reduce((sum, item) => sum + (item.minutesWatched || 0), 0);
  const hoursWatched = Math.floor(totalMinutesWatched / 60);
  const remainingMinutes = totalMinutesWatched % 60;

  return (
    <div className="stats-overview">
      <h2>Your Statistics</h2>
      <div className="stats-grid">
        <div className="stat-card">
          <h3>Total Media</h3>
          <p>{mediaItems.length}</p>
        </div>
        <div className="stat-card">
          <h3>Movies</h3>
          <p>{movies.length}</p>
        </div>
        <div className="stat-card">
          <h3>TV Series</h3>
          <p>{tvSeries.length}</p>
        </div>
        <div className="stat-card">
          <h3>Total Watch Time</h3>
          <p>{hoursWatched}h {remainingMinutes}m</p>
        </div>
      </div>
    </div>
  );
};

export default StatsOverview;