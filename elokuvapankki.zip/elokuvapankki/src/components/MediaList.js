import React, { useState, useEffect } from 'react';
import { loadFromLocalStorage, saveToLocalStorage } from '../utils/storage';
import ProgressTracker from './ProgressTracker';

const MediaList = ({ refreshFlag, onMediaChange }) => {
  const [mediaItems, setMediaItems] = useState([]);
  const [selectedMedia, setSelectedMedia] = useState(null);

  // Load media items when component mounts or refreshFlag changes
  useEffect(() => {
    setMediaItems(loadFromLocalStorage('mediaItems') || []);
  }, [refreshFlag]);

  // NEW: Improved delete function with immediate refresh
  const handleDelete = (id) => {
    const updatedMedia = mediaItems.filter(item => item.id !== id);
    saveToLocalStorage('mediaItems', updatedMedia);
    
    // Also remove any progress for this media
    const progress = loadFromLocalStorage('userProgress') || [];
    const updatedProgress = progress.filter(p => p.mediaId !== id);
    saveToLocalStorage('userProgress', updatedProgress);
    
    // Trigger refresh
    onMediaChange();
  };

  return (
    <div className="media-list">
      <h2>Your Media Collection</h2>
      {mediaItems.length === 0 ? (
        <p>No media items added yet.</p>
      ) : (
        <ul>
          {mediaItems.map(item => (
            <li key={item.id} className="media-item">
              <div>
                <h3>{item.title}</h3>
                <p>Type: {item.mediaType}</p>
                {item.mediaType === 'TV Series' && (
                  <p>Seasons: {item.totalSeasons}, Episodes: {item.totalEpisodes}</p>
                )}
                {item.mediaType === 'Movie' && (
                  <p>Duration: {item.totalMinutes} minutes</p>
                )}
              </div>
              <div className="media-actions">
                <button onClick={() => setSelectedMedia(item)}>Update Progress</button>
                <button onClick={() => handleDelete(item.id)}>Delete</button>
              </div>
            </li>
          ))}
        </ul>
      )}
      
      {selectedMedia && (
        <ProgressTracker 
          media={selectedMedia} 
          onClose={() => setSelectedMedia(null)}
          // NEW: Pass the refresh callback
          onProgressUpdate={onMediaChange}
        />
      )}
    </div>
  );
};

export default MediaList;