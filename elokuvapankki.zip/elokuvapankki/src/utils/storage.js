export const saveToLocalStorage = (key, data) => {
    try {
      localStorage.setItem(key, JSON.stringify(data));
    } catch (error) {
      console.error('Error saving to localStorage:', error);
    }
  };
  
  export const loadFromLocalStorage = (key) => {
    try {
      const data = localStorage.getItem(key);
      return data ? JSON.parse(data) : null;
    } catch (error) {
      console.error('Error loading from localStorage:', error);
      return null;
    }
  };
  
  export const MEDIA_TYPES = {
    MOVIE: 'Movie',
    TV_SERIES: 'TV Series'
  };
  
  export const initializeStorage = () => {
    if (!loadFromLocalStorage('mediaItems')) {
      saveToLocalStorage('mediaItems', []);
    }
    if (!loadFromLocalStorage('userProgress')) {
      saveToLocalStorage('userProgress', []);
    }
  };