import React, { useState, useEffect } from 'react';
import { initializeStorage } from './utils/storage';
import AddMediaForm from './components/AddMediaForm';
import MediaList from './components/MediaList';
import StatsOverview from './components/StatsOverview';
import './App.css';

function App() {
  const [refreshFlag, setRefreshFlag] = useState(false);

  useEffect(() => {
    initializeStorage();
  }, []);

  // NEW: Single handler for all data changes
  const handleDataChange = () => {
    setRefreshFlag(prev => !prev);
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>Movie Database</h1>
        <p>Track your movies and TV series</p>
      </header>
      
      <main>
        <div className="content-section">
          <AddMediaForm onAdd={handleDataChange} />
        </div>
        
        <div className="content-section">
          <StatsOverview refreshFlag={refreshFlag} />
        </div>
        
        <div className="content-section">
          {/* NEW: Added onMediaChange prop */}
          <MediaList refreshFlag={refreshFlag} onMediaChange={handleDataChange} />
        </div>
      </main>
    </div>
  );
}

export default App;